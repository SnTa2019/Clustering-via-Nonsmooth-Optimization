!*************************************************************************
!*                                                                       *
!*     DC Optimization based incremental clustering using L2 norm        *
!*                                                                       *
!*     Original code with DC-Clust algorithm by Adil Bagirov 2015.       *                     
!*                                                                       *
!*     Fortran 95 version and optimization with DCDB method              *
!*     by Napsu Karmitsa 2016 (last modified 24.02.2016).                *
!*                                                                       *
!*                                                                       *
!*     The software is free for academic teaching and research           *
!*     purposes but I ask you to refer the references given below,       *
!*     if you use it.                                                    *
!*                                                                       *
!*************************************************************************
!*
!*
!*     Codes included:
!*
!*     dcclustering.f95      - Mainprogram for clustering software
!*                             (this file).
!*     parameters.f95        - Parameters. Inludes modules:
!*                               - r_precision - Precision for reals,
!*                               - param - Parameters,
!*                               - exe_time - Execution time.
!*     initclust.f95         - initialization of clustering parameters and
!*                             optimization methods. Includes modules:
!*                               - initclust - Initialization of parameters for
!*                                 clustering.
!*                               - initdcclust - Initialization of DC-Clust -solver.
!*                               - initdcdb - Initialization of DCDB -solver.
!*     clusteringmod.f95     - Subroutines for clustering software.
!*     functionmod.f95       - Computation of function and (sub)gradients values for
!*                             clustering software.
!*     dcclust_method.f95    - DC-Clust method.
!*     dcdb.f95              - DCDB method.
!*     dcfun.f95             - Computation of the function and (sub)gradients
!*                             values for DCDB.
!*     subpro.f95            - subprograms for DCDB.
!*
!*     iris.txt              - sample data set
!*
!*     Makefile              - makefile.
!*
!*
!*     To use the software modify initclust.f95 (and dcclustering.f95) as needed
!*     and give your data set similar to iris.txt here.
!*
!*
!*     References:
!*
!*     "New diagonal bundle method for clustering problems in very large data sets",
!*     Napsu Karmitsa, Adil Bagirov and Sona Taheri, 2016.
!*
!*     "Nonsmooth DC programming approach to the minimum sum-of-squares 
!*     clustering problems", Adil Bagirov, Sona Taheri and Julien Ugon, 
!*     Pattern Recognition, Vol. 53, pp. 12–24, 2016.
!*
!*     Acknowledgements: 
!*
!*     The work was financially supported by the Academy of Finland (Project No. 289500)
!*     and Australian Research Counsil's Discovery Projects funding scheme (Project No.
!*     DP140103213).
!*
!*************************************************************************
